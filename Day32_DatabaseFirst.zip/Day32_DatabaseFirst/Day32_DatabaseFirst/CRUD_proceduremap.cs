﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day32_DatabaseFirst
{
    class CRUD_proceduremap
    {
        static void Main(string[] args)
        {
            MyDbEntities db = new MyDbEntities();

            int ch, id;

            do
            {
                Console.WriteLine("1 INSERT RECORD");
                Console.WriteLine("2 DISPLAY RECORD");
                Console.WriteLine("3 UPDATE RECORD");
                Console.WriteLine("4 SEARCH RECORD");
                Console.WriteLine("5 DELETE RECORD");
                Console.WriteLine("6 EXIT");
                ch = int.Parse(Console.ReadLine());
                Deptloc ob = new Deptloc();
                switch (ch)
                {
                    case 1:

                        Console.Write("AREA ID       = ");
                        ob.AreaId = int.Parse(Console.ReadLine());
                        Console.Write("AREA NAME      = ");
                        ob.AreaName = Console.ReadLine();
                        Console.Write("CITY ID        = ");
                        ob.Cid = int.Parse(Console.ReadLine());
                        Console.Write("STREET NUMBER   = ");
                        ob.Streetnum = int.Parse(Console.ReadLine());
                        Console.WriteLine();
                        db.Deptlocs.Add(ob);
                        db.SaveChanges();
                        break;
                    case 2:
                        foreach (Deptloc d in db.selectalldeptloc())
                        {
                            Console.Write(d.AreaId + "\t");
                            Console.Write(d.AreaName + "\t");
                            Console.Write(d.Cid + "\t");
                            Console.Write(d.Streetnum + "\t");
                            Console.Write(d.City.CityName + "\t");

                            Console.WriteLine();
                        }

                        break;
                    case 3:
                        Console.Write("AREA ID       = ");
                        id = int.Parse(Console.ReadLine());

                        ob = db.Deptlocs.Find(id);

                        if (ob == null)
                            Console.WriteLine("Cannot update as the id not found");
                        else
                        {
                            Console.Write("AREA NAME      = ");
                            ob.AreaName = Console.ReadLine();
                            Console.Write("CITY ID        = ");
                            ob.Cid = int.Parse(Console.ReadLine());
                            Console.Write("STREET NUMBER   = ");
                            ob.Streetnum = int.Parse(Console.ReadLine());
                            Console.WriteLine();

                            db.SaveChanges();

                        }



                        break;
                    case 4:
                        Console.Write("AREA ID       = ");
                        id = int.Parse(Console.ReadLine());

                        ob = db.Deptlocs.Find(id);

                        if (ob == null)
                            Console.WriteLine("Cannot find the record for given id = " + id);
                        else
                        {
                            Console.WriteLine("AREA NAME      = " + ob.AreaName);
                            Console.WriteLine("CITY ID        = " + ob.Cid);
                            Console.WriteLine("Street NUMBER  = " + ob.Streetnum);
                        }
                        break;
                    case 5:
                        Console.Write("AREA ID       = ");
                        id = int.Parse(Console.ReadLine());

                        ob = db.Deptlocs.Find(id);

                        if (ob == null)
                            Console.WriteLine("Cannot find the record for given id = " + id);
                        else
                        {
                            db.Deptlocs.Remove(ob);
                            Console.WriteLine("Data entry is deleted");
                            db.SaveChanges();
                        }
                        break;
                    case 6:
                        break;
                    default:
                        Console.WriteLine("Invalid choice");
                        break;
                }
            } while (ch != 6);

        }
    }
}
