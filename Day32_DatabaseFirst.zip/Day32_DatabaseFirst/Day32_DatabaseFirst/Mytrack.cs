﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day32_DatabaseFirst
{
    class Mytrack
    {
        static void Main(string[] args)
        {
            MyDbEntities db = new MyDbEntities();

            Deptloc ob = new Deptloc() { AreaId = 55, AreaName = "Kormangala", Cid = 444, Streetnum = 15 };

            db.Deptlocs.Add(ob);

            Console.WriteLine("After adding ");

            foreach(var tracker in db.ChangeTracker.Entries<Deptloc>())
            {
                Console.WriteLine(tracker.State);
            }

            Deptloc mod = db.Deptlocs.Find(1);
            if(mod!=null)
            {
                mod.Streetnum = 88;
            }
            Console.WriteLine("\n\nAfter modifying ");

            foreach (var tracker in db.ChangeTracker.Entries<Deptloc>())
            {
                Console.WriteLine(tracker.State);
            }
            Deptloc del1 = db.Deptlocs.Find(1);
            if (del1 != null)
            {
                db.Deptlocs.Remove(del1);
            }
            Console.WriteLine("\n\nAfter deleting ");

            foreach (var tracker in db.ChangeTracker.Entries<Deptloc>())
            {
                Console.WriteLine(tracker.State);
            }

            db.SaveChanges();
        }
    }
}
