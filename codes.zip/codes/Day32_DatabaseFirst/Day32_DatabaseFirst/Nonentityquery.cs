﻿using System;
namespace Day32_DatabaseFirst
{
    class Nonentityquery
    {
        static void Main(string[] args)
        {
            MyDbEntities db = new MyDbEntities();
            var myob = db.Database.SqlQuery<MyArea>("select AreaName ,Streetnum from Deptloc");

            foreach(MyArea m in   myob)
            {
                Console.WriteLine("{0}\t{1}",m.AreaName.PadRight(20),m.Streetnum);
            }
        }
    }
}
