﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day32_DatabaseFirst
{
    class Eagerloading
    {
        static void Main(string[] args)
        {
            MyDbEntities db = new MyDbEntities();

            foreach (City c in db.Cities.Include("Deptlocs"))
            {
                Console.WriteLine("CITY ID  = {0} \t CITY NAME = {1}", c.Cid, c.CityName);
                foreach (Deptloc d in c.Deptlocs)
                {
                    Console.WriteLine("AREA NAME = {0} with id = {1}", d.AreaName, d.AreaId);
                }
            }
        }
    }
}
