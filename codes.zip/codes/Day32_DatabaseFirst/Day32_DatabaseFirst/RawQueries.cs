﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day32_DatabaseFirst
{
    class RawQueries
    {
        static void Main(string[] args)
        {
            MyDbEntities db = new MyDbEntities();

            #region Entity based query
            Console.WriteLine("Enter the id ");
            int id = int.Parse(Console.ReadLine());

            SqlParameter myvar = new SqlParameter();
            myvar.ParameterName = "@id";
            myvar.Value = id;
            myvar.SqlDbType = System.Data.SqlDbType.Int;

            string sql = "select * from DEPTLOC where CID = @id";
            //Console.WriteLine(sql);
            IEnumerable<Deptloc> listloc = db.Deptlocs.SqlQuery(sql, myvar);

            //Console.WriteLine(listloc.Count());

            if(listloc.Count() == 0)
                Console.WriteLine("No records for id =111");
            foreach(Deptloc d in listloc)
            {
                Console.WriteLine("Area name = {0}",d.AreaName);
            }

            #endregion





        }
    }
}
