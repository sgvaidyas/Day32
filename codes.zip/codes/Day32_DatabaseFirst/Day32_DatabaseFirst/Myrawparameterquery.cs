﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Data.SqlClient;

namespace Day32_DatabaseFirst
{
    class Myrawparameterquery
    {
        static void Main(string[] args)
        {
            MyDbEntities db = new MyDbEntities();

            #region Entity Paramaterized based query
            Console.WriteLine("Enter the id ");
            int id = int.Parse(Console.ReadLine());

            SqlParameter myvar1 = new SqlParameter();
            myvar1.ParameterName = "@cid";
            myvar1.Value = id;
            myvar1.SqlDbType = System.Data.SqlDbType.Int;

            string sql = "select * from DEPTLOC where CID = @cid";
            //Console.WriteLine(sql);
            IEnumerable<Deptloc> listloc = db.Deptlocs.SqlQuery(sql, myvar1);

            //Console.WriteLine(listloc.Count());

            
            foreach (Deptloc d in listloc)
            {
                Console.WriteLine("Area name = {0}", d.AreaName);
            }

            #endregion
        }
    }
}
