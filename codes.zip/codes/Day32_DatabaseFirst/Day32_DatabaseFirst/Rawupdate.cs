﻿using System;
using System.Data.SqlClient;
namespace Day32_DatabaseFirst
{
    class Rawupdate
    {
        static void Main(string[] args)
        {
            MyDbEntities db = new MyDbEntities();

            string areaname;
            int streetnum;

            Console.Write("Enter the areaname =  ");
            areaname = Console.ReadLine();

            Console.Write("Enter the streetnum =  ");
            streetnum = int.Parse(Console.ReadLine());


            Console.Write("Enter the AreaId =  ");
            int areaid = int.Parse(Console.ReadLine());


            SqlParameter aname = new SqlParameter();
            aname.ParameterName = "@aname";
            aname.Value = areaname;
            aname.SqlDbType = System.Data.SqlDbType.VarChar;
            aname.Size = 50;

            SqlParameter sn =
    new SqlParameter() { ParameterName = "@streetnum", SqlDbType = System.Data.SqlDbType.Int, Value = streetnum };


            SqlParameter aid =
    new SqlParameter() { ParameterName = "@areaid", SqlDbType = System.Data.SqlDbType.Int, Value = areaid };


            //string sql = "update DeptLoc set AreaName ='"+ areaname + "'  , Streetnum = "+streetnum+" where AreaId="+areaid;
            int res = db.Database.ExecuteSqlCommand("update DeptLoc set AreaName = @aname, Streetnum = @streetnum where AreaId = @areaid", aname, sn, aid);

            if (res == 1)
                Console.WriteLine("SUCCESSFULLY UPDATED ");
            else
                Console.WriteLine("RECORD NOT FOUND WRT THE ID");
        }
    }
}
