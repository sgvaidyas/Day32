﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day32_DatabaseFirst
{
    class MyArea
    {
        public string AreaName { get; set; }
        public int Streetnum { get; set; }
    }
}
